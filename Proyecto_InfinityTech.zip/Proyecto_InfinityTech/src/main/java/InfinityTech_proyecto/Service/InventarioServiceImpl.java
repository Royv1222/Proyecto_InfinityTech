/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Repuesto;
import InfinityTech_proyecto.Domain.Ticket;
import InfinityTech_proyecto.Domain.TicketRepuesto;
import InfinityTech_proyecto.Repository.RepuestoRepository;
import InfinityTech_proyecto.Repository.TicketRepuestoRepository;
import InfinityTech_proyecto.Repository.TicketRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioServiceImpl implements InventarioService {

    private final TicketRepository ticketRepo;
    private final RepuestoRepository repuestoRepo;
    private final TicketRepuestoRepository trRepo;

    public InventarioServiceImpl(TicketRepository ticketRepo, RepuestoRepository repuestoRepo, TicketRepuestoRepository trRepo) {
        this.ticketRepo = ticketRepo;
        this.repuestoRepo = repuestoRepo;
        this.trRepo = trRepo;
    }

    @Override
    public TicketRepuesto reservar(Integer idTicket, Integer idRepuesto, Integer cantidad) {
        Ticket t = ticketRepo.findById(idTicket).orElse(null);
        Repuesto r = repuestoRepo.findById(idRepuesto).orElse(null);
        if (t == null || r == null) return null;

        if (r.getStockActual() < cantidad) throw new IllegalArgumentException("Stock insuficiente");

        r.setStockActual(r.getStockActual() - cantidad);
        repuestoRepo.save(r);

        TicketRepuesto tr = new TicketRepuesto();
        tr.setTicket(t);
        tr.setRepuesto(r);
        tr.setCantidad(cantidad);
        tr.setEstado(TicketRepuesto.EstadoMov.RESERVADO);
        return trRepo.save(tr);
    }

    @Override
    public TicketRepuesto consumir(Integer idTicket, Integer idRepuesto, Integer cantidad) {
        TicketRepuesto tr = trRepo
                .findByTicket_IdTicketAndRepuesto_IdRepuestoAndEstado(idTicket, idRepuesto, TicketRepuesto.EstadoMov.RESERVADO)
                .orElse(null);
        if (tr == null) throw new IllegalArgumentException("No hay repuesto reservado para consumir");

        tr.setEstado(TicketRepuesto.EstadoMov.CONSUMIDO);
        return trRepo.save(tr);
    }

    @Override
    public TicketRepuesto devolver(Integer idTicket, Integer idRepuesto, Integer cantidad) {
        TicketRepuesto tr = trRepo
                .findByTicket_IdTicketAndRepuesto_IdRepuestoAndEstado(idTicket, idRepuesto, TicketRepuesto.EstadoMov.RESERVADO)
                .orElse(null);
        if (tr == null) throw new IllegalArgumentException("No hay repuesto reservado para devolver");

        Repuesto r = tr.getRepuesto();
        r.setStockActual(r.getStockActual() + tr.getCantidad());
        repuestoRepo.save(r);

        tr.setEstado(TicketRepuesto.EstadoMov.DEVUELTO);
        return trRepo.save(tr);
    }

    @Override
    public List<TicketRepuesto> movimientosPorTicket(Integer idTicket) {
        return trRepo.findByTicket_IdTicket(idTicket);
    }
}
