/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Reparacion;
import java.util.List;

public interface ReparacionService {
    Reparacion iniciar(Integer idTicket, Integer idTecnico, Reparacion.Tipo tipo);
    Reparacion finalizar(Integer idTiempo);
    List<Reparacion> porTicket(Integer idTicket);
}

