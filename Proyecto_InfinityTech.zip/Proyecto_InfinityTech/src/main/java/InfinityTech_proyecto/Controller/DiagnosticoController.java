/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.Diagnostico;
import InfinityTech_proyecto.Service.DiagnosticoService;
import InfinityTech_proyecto.Service.TecnicoService;
import InfinityTech_proyecto.Service.TicketService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/diagnosticos")
public class DiagnosticoController {

    private final DiagnosticoService diagnosticoService;
    private final TicketService ticketService;
    private final TecnicoService tecnicoService;

    public DiagnosticoController(DiagnosticoService diagnosticoService,
                                 TicketService ticketService,
                                 TecnicoService tecnicoService) {
        this.diagnosticoService = diagnosticoService;
        this.ticketService = ticketService;
        this.tecnicoService = tecnicoService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("diagnosticos", diagnosticoService.findAll());
        return "diagnosticos/form"; // o "diagnosticos/list"
    }

    @GetMapping("/nuevo/{idTicket}")
    public String form(@PathVariable Integer idTicket, Model model) {
        Diagnostico d = new Diagnostico();
        d.setTicket(ticketService.findById(idTicket));
        model.addAttribute("diagnostico", d);
        model.addAttribute("tecnicos", tecnicoService.listarTecnicos());
        return "diagnosticos/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Diagnostico d) {
        diagnosticoService.save(d);
        return "redirect:/tickets";
    }
}