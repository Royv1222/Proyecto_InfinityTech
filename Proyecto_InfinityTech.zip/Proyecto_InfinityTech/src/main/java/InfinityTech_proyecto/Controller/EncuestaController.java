package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.Encuesta;
import InfinityTech_proyecto.Service.EncuestaService;
import InfinityTech_proyecto.Service.TicketService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/encuestas")
public class EncuestaController {

    private final EncuestaService encuestaService;
    private final TicketService ticketService;

    public EncuestaController(EncuestaService encuestaService, TicketService ticketService) {
        this.encuestaService = encuestaService;
        this.ticketService = ticketService;
    }

    @GetMapping("/responder/{idTicket}")
    public String responderForm(@PathVariable Integer idTicket, Model model) {
        Encuesta e = encuestaService.findByTicket(idTicket);
        if (e == null) {
            e = new Encuesta();
            e.setTicket(ticketService.findById(idTicket));
            e.setCliente(ticketService.findById(idTicket).getCliente());
        }
        model.addAttribute("encuesta", e);
        return "encuestas/responder";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Encuesta e) {
        encuestaService.save(e);
        return "redirect:/home";
    }
}
