package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Controller.SolicitudForm;
import InfinityTech_proyecto.Domain.Cliente;
import InfinityTech_proyecto.Domain.Equipo;
import InfinityTech_proyecto.Domain.EstadoTicket;
import InfinityTech_proyecto.Domain.Ticket;
import InfinityTech_proyecto.Repository.ClienteRepository;
import InfinityTech_proyecto.Repository.EquipoRepository;
import InfinityTech_proyecto.Repository.EstadoTicketRepository;
import InfinityTech_proyecto.Repository.TicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class SolicitudPublicServiceImpl implements SolicitudPublicService {

    private final ClienteRepository clienteRepo;
    private final EquipoRepository equipoRepo;
    private final TicketRepository ticketRepo;
    private final EstadoTicketRepository estadoRepo;

    public SolicitudPublicServiceImpl(
            ClienteRepository clienteRepo,
            EquipoRepository equipoRepo,
            TicketRepository ticketRepo,
            EstadoTicketRepository estadoRepo
    ) {
        this.clienteRepo = clienteRepo;
        this.equipoRepo = equipoRepo;
        this.ticketRepo = ticketRepo;
        this.estadoRepo = estadoRepo;
    }

    @Override
    @Transactional
    public String crearSolicitud(SolicitudForm f) {

        // 1) Cliente (sin login)
        Cliente cliente = clienteRepo.findByCedula(f.getCedula())
                .or(() -> clienteRepo.findByCorreo(f.getCorreo()))
                .orElseGet(Cliente::new);

        cliente.setCedula(f.getCedula());
        cliente.setNombre(f.getNombre());
        cliente.setApellidos(f.getApellidos());
        cliente.setCorreo(f.getCorreo());
        cliente.setTelefono(f.getTelefono());
        cliente.setDireccion(f.getDireccion());
        cliente.setActivo(true);

        cliente = clienteRepo.save(cliente);

        // 2) Equipo
        Equipo equipo = new Equipo();
        equipo.setCliente(cliente);
        equipo.setTipoEquipo(f.getTipoEquipo());
        equipo.setMarca(f.getMarca());
        equipo.setModelo(f.getModelo());
        equipo.setSerie(f.getSerie());
        equipo = equipoRepo.save(equipo);

        // 3) Estado RECIBIDO (tabla estados_ticket)
        EstadoTicket recibido = estadoRepo.findByNombre("RECIBIDO")
                .orElseThrow(() -> new IllegalStateException("No existe estado_ticket 'RECIBIDO' en BD"));

        // 4) Ticket
        Ticket t = new Ticket();
        t.setFolio(generarFolioUnico());
        t.setCliente(cliente);
        t.setEquipo(equipo);
        t.setEstado(recibido);
        t.setDescripcionFalla(f.getDescripcionFalla());

        ticketRepo.save(t);
        return t.getFolio();
    }

    @Override
    public Optional<Ticket> buscarPorFolio(String folio) {
        return ticketRepo.findByFolio(folio);
    }

    private String generarFolioUnico() {
        return "TCK-" + System.currentTimeMillis();
    }
}
