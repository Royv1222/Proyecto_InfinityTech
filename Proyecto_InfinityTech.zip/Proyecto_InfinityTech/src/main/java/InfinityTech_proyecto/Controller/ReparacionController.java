package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.Reparacion;
import InfinityTech_proyecto.Service.ReparacionService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reparaciones")
public class ReparacionController {

    private final ReparacionService service;

    public ReparacionController(ReparacionService service) { this.service = service; }

    @PostMapping("/iniciar")
    public String iniciar(@RequestParam Integer idTicket, @RequestParam Integer idTecnico) {
        service.iniciar(idTicket, idTecnico, Reparacion.Tipo.REPARACION);
        return "redirect:/tickets";
    }

    @PostMapping("/finalizar")
    public String finalizar(@RequestParam Integer idTiempo) {
        service.finalizar(idTiempo);
        return "redirect:/tickets";
    }
}