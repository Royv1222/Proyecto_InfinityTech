package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Controller.SolicitudForm;
import InfinityTech_proyecto.Domain.Ticket;

import java.util.Optional;

public interface SolicitudPublicService {
    String crearSolicitud(SolicitudForm form);
    Optional<Ticket> buscarPorFolio(String folio);
}