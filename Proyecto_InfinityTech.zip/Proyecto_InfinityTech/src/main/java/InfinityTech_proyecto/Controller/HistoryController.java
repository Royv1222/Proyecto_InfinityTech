/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hu.JoseCuadra.controller;

/**
Grupo 3
Avance 3
Hecho por Jose Daniel Ramírez Leitón y Sebastián Cuadra Corrales.
HU11, HU12, HU13, HU14 y HU15.
 */

import com.hu.JoseCuadra.services.TicketService;
import com.hu.JoseCuadra.models.Ticket;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/history")
public class HistoryController {

    @Autowired
    private TicketService service;

    @GetMapping
    public String search() {
        return "history/search";
    }

    @PostMapping("/results")
    public String results(@RequestParam(required=false) String clienteId,
                          @RequestParam(required=false) String email,
                          Model model) {

        List<Ticket> tickets;

        if (clienteId != null && !clienteId.isBlank()) {
            tickets = service.findByClienteId(clienteId);
        } else if (email != null && !email.isBlank()) {
            tickets = service.findByClienteEmail(email);
        } else {
            tickets = List.of();
        }

        model.addAttribute("tickets", tickets);
        return "history/results";
    }

    @GetMapping("/{folio}")
    public String detail(@PathVariable String folio, Model model) {
        Ticket t = service.findByFolio(folio);
        model.addAttribute("ticket", t);
        return "history/detail";
    }
}
