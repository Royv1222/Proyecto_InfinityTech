/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ticket_repuestos",
       uniqueConstraints = @UniqueConstraint(name="uq_ticket_repuesto_estado", columnNames={"id_ticket","id_repuesto","estado"}))
public class TicketRepuesto {

    public enum EstadoMov { RESERVADO, CONSUMIDO, DEVUELTO }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tr_ticket_rep")
    private Integer idTrTicketRep;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_ticket")
    private Ticket ticket;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_repuesto")
    private Repuesto repuesto;

    @Column(nullable = false)
    private Integer cantidad;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoMov estado = EstadoMov.RESERVADO;

    @Column(name = "fecha_mov", nullable = false)
    private LocalDateTime fechaMov;

    @PrePersist
    void onCreate() { if (fechaMov == null) fechaMov = LocalDateTime.now(); }

    public Integer getIdTrTicketRep() { return idTrTicketRep; }
    public void setIdTrTicketRep(Integer idTrTicketRep) { this.idTrTicketRep = idTrTicketRep; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) { this.ticket = ticket; }

    public Repuesto getRepuesto() { return repuesto; }
    public void setRepuesto(Repuesto repuesto) { this.repuesto = repuesto; }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public EstadoMov getEstado() { return estado; }
    public void setEstado(EstadoMov estado) { this.estado = estado; }

    public LocalDateTime getFechaMov() { return fechaMov; }
    public void setFechaMov(LocalDateTime fechaMov) { this.fechaMov = fechaMov; }
}
