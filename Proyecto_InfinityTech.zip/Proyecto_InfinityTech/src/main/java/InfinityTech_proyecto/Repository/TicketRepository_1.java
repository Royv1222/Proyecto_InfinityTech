/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hu.JoseCuadra.repository;

/**
Grupo 3
Avance 3
Hecho por Jose Daniel Ramírez Leitón y Sebastián Cuadra Corrales.
HU11, HU12, HU13, HU14 y HU15.
 */

import com.hu.JoseCuadra.models.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
    List<Ticket> findByClienteId(String clienteId);
    List<Ticket> findByClienteEmail(String email);
    Optional<Ticket> findByFolio(String folio);
}
