/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hu.JoseCuadra.services;

/**
Grupo 3
Avance 3
Hecho por Jose Daniel Ramírez Leitón y Sebastián Cuadra Corrales.
HU11, HU12, HU13, HU14 y HU15.
 */

import com.hu.JoseCuadra.models.Ticket;
import com.hu.JoseCuadra.repository.TicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class TicketService {

    @Autowired
    private TicketRepository repo;

    public List<Ticket> findByClienteId(String id) {
        return repo.findByClienteId(id);
    }

    public List<Ticket> findByClienteEmail(String email) {
        return repo.findByClienteEmail(email);
    }

    public Ticket findByFolio(String folio) {
        return repo.findByFolio(folio).orElse(null);
    }
}
