/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Historias.demo.domain;


public class Repuesto {
    private String nombre;
    private int stock;
    private Integer minimo;

    public Repuesto(String nombre, int stock, Integer minimo) {
        this.nombre = nombre;
        this.stock = stock;
        this.minimo = minimo;
    }

    public String getNombre() { return nombre; }
    public int getStock() { return stock; }
    public Integer getMinimo() { return minimo; }

    public void setStock(int stock) { this.stock = stock; }
}
