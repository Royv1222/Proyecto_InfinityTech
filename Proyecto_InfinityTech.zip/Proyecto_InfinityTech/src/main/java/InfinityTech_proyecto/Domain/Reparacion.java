/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tiempos_actividad")
public class Reparacion {

    public enum Tipo { DIAGNOSTICO, REPARACION }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tiempo")
    private Integer idTiempo;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_ticket")
    private Ticket ticket;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_tecnico")
    private User tecnico;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Tipo tipo;

    @Column(nullable = false)
    private LocalDateTime inicio;

    @Column
    private LocalDateTime fin;

    @PrePersist
    void onCreate() { if (inicio == null) inicio = LocalDateTime.now(); }

    public Integer getIdTiempo() { return idTiempo; }
    public void setIdTiempo(Integer idTiempo) { this.idTiempo = idTiempo; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) { this.ticket = ticket; }

    public User getTecnico() { return tecnico; }
    public void setTecnico(User tecnico) { this.tecnico = tecnico; }

    public Tipo getTipo() { return tipo; }
    public void setTipo(Tipo tipo) { this.tipo = tipo; }

    public LocalDateTime getInicio() { return inicio; }
    public void setInicio(LocalDateTime inicio) { this.inicio = inicio; }

    public LocalDateTime getFin() { return fin; }
    public void setFin(LocalDateTime fin) { this.fin = fin; }
}
