/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Presupuesto;
import InfinityTech_proyecto.Domain.Ticket;
import InfinityTech_proyecto.Repository.PresupuestoRepository;
import InfinityTech_proyecto.Repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class PresupuestoServiceImpl implements PresupuestoService {

    private final PresupuestoRepository repo;
    private final TicketRepository ticketRepo;

    public PresupuestoServiceImpl(PresupuestoRepository repo, TicketRepository ticketRepo) {
        this.repo = repo;
        this.ticketRepo = ticketRepo;
    }

    @Override
    public Presupuesto generarParaTicket(Integer idTicket, Double tarifaHora, Double impuestos) {
        Ticket t = ticketRepo.findById(idTicket).orElse(null);
        if (t == null) return null;

        Presupuesto p = repo.findByTicket_IdTicket(idTicket).orElse(new Presupuesto());
        p.setTicket(t);
        p.setTarifaHora(tarifaHora != null ? tarifaHora : 0.0);
        p.setImpuestos(impuestos != null ? impuestos : 0.0);

        // por simplicidad: total = subtotal_mano_obra + subtotal_repuestos + impuestos
        p.setSubtotalManoObra(p.getManoObraHoras() * p.getTarifaHora());
        p.setTotal(p.getSubtotalManoObra() + p.getSubtotalRepuestos() + p.getImpuestos());

        return repo.save(p);
    }

    @Override public Presupuesto findByTicket(Integer idTicket) { return repo.findByTicket_IdTicket(idTicket).orElse(null); }
    @Override public Presupuesto save(Presupuesto p) { return repo.save(p); }
}
