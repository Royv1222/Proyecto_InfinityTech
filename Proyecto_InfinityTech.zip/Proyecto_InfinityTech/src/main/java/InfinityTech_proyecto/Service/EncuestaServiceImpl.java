/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Encuesta;
import InfinityTech_proyecto.Repository.EncuestaRepository;
import org.springframework.stereotype.Service;

@Service
public class EncuestaServiceImpl implements EncuestaService {

    private final EncuestaRepository repo;

    public EncuestaServiceImpl(EncuestaRepository repo) { this.repo = repo; }

    @Override public Encuesta save(Encuesta e) { return repo.save(e); }
    @Override public Encuesta findByTicket(Integer idTicket) { return repo.findByTicket_IdTicket(idTicket).orElse(null); }
}
