/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Historias.demo.service;


import Historias.demo.domain.Indicadores;

public class IndicadoresService {

    public Indicadores obtenerIndicadores() {
        // Ejemplo simulado
        int tickets = 5;
        double tiempo = 3.4;
        int repuestos = 12;

        if (tickets == 0 && repuestos == 0) {
            throw new RuntimeException("No hay información para mostrar");
        }

        return new Indicadores(tickets, tiempo, repuestos);
    }
}
