/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Service.StockService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/reportes")
public class IndicadoresController {

    private final StockService stockService;

    public IndicadoresController(StockService stockService) { this.stockService = stockService; }

    @GetMapping("/panel-indicadores")
    public String panel(Model model) {
        model.addAttribute("totalRepuestos", stockService.totalRepuestos());
        model.addAttribute("repuestosActivos", stockService.repuestosActivos());
        return "admin/reportes/panel-indicadores";
    }

    @GetMapping("/stock")
    public String stock(Model model) {
        model.addAttribute("totalRepuestos", stockService.totalRepuestos());
        model.addAttribute("repuestosActivos", stockService.repuestosActivos());
        return "admin/reportes/stock";
    }
}
