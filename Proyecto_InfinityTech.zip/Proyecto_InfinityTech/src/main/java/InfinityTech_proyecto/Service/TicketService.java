/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Ticket;
import java.util.List;

public interface TicketService {
    Ticket save(Ticket t);
    Ticket findById(Integer id);
    List<Ticket> findAll();
    void delete(Integer id);


    Ticket asignarTecnico(Integer idTicket, Integer idTecnico);
    Ticket cambiarEstado(Integer idTicket, String nombreEstado);
     Ticket buscarPorFolio(String folio);
}
