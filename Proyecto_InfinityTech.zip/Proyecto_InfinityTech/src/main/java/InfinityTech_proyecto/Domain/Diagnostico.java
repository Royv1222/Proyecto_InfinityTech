/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "diagnosticos")
public class Diagnostico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_diagnostico")
    private Integer idDiagnostico;

    @OneToOne(optional = false)
    @JoinColumn(name = "id_ticket", unique = true)
    private Ticket ticket;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_tecnico")
    private User tecnico;

    @Lob
    @Column(nullable = false)
    private String hallazgos;

    @Lob
    @Column(name = "pruebas_realizadas")
    private String pruebasRealizadas;

    @Lob
    @Column(name = "fotos_url")
    private String fotosUrl;

    @Column(name = "horas_estimadas")
    private Double horasEstimadas = 0.0;

    @Column(name = "fecha_diagnostico", nullable = false)
    private LocalDateTime fechaDiagnostico;

    @PrePersist
    void onCreate() { if (fechaDiagnostico == null) fechaDiagnostico = LocalDateTime.now(); }

    public Integer getIdDiagnostico() { return idDiagnostico; }
    public void setIdDiagnostico(Integer idDiagnostico) { this.idDiagnostico = idDiagnostico; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) { this.ticket = ticket; }

    public User getTecnico() { return tecnico; }
    public void setTecnico(User tecnico) { this.tecnico = tecnico; }

    public String getHallazgos() { return hallazgos; }
    public void setHallazgos(String hallazgos) { this.hallazgos = hallazgos; }

    public String getPruebasRealizadas() { return pruebasRealizadas; }
    public void setPruebasRealizadas(String pruebasRealizadas) { this.pruebasRealizadas = pruebasRealizadas; }

    public String getFotosUrl() { return fotosUrl; }
    public void setFotosUrl(String fotosUrl) { this.fotosUrl = fotosUrl; }

    public Double getHorasEstimadas() { return horasEstimadas; }
    public void setHorasEstimadas(Double horasEstimadas) { this.horasEstimadas = horasEstimadas; }

    public LocalDateTime getFechaDiagnostico() { return fechaDiagnostico; }
    public void setFechaDiagnostico(LocalDateTime fechaDiagnostico) { this.fechaDiagnostico = fechaDiagnostico; }
}