/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Cliente;
import InfinityTech_proyecto.Repository.ClienteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ClienteServiceImpl implements ClienteService {

    private final ClienteRepository repo;

    public ClienteServiceImpl(ClienteRepository repo) {
        this.repo = repo;
    }

    @Override public Cliente save(Cliente c) { return repo.save(c); }
    @Override public Cliente findById(Integer id) { return repo.findById(id).orElse(null); }
    @Override public List<Cliente> findAll() { return repo.findAll(); }
    @Override public void delete(Integer id) { repo.deleteById(id); }
    @Override public Cliente findByCedula(String cedula) { return repo.findByCedula(cedula).orElse(null); }
}
