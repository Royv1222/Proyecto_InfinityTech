/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Historias.demo.service;

import Historias.demo.domain.OrdenServicio;
import Historias.demo.repository.OrdenServicioRepository;

import java.util.List;
import java.util.UUID;

public class OrdenServicioService {

    private OrdenServicioRepository repository = new OrdenServicioRepository();

    public OrdenServicio generarOrden(String cliente, String equipo, List<String> accesorios) {
        if (cliente.isEmpty() || equipo.isEmpty()) {
            throw new RuntimeException("Complete los campos obligatorios");
        }

        String folio = UUID.randomUUID().toString().substring(0, 8);

        OrdenServicio orden = new OrdenServicio(folio, cliente, equipo, accesorios);
        repository.guardar(orden);

        // Aquí iría la generación del PDF real
        System.out.println("PDF generado para la orden: " + folio);

        return orden;
    }
}
