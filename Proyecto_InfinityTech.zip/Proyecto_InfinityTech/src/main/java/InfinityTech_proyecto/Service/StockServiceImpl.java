/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Repository.RepuestoRepository;
import org.springframework.stereotype.Service;

@Service
public class StockServiceImpl implements StockService {

    private final RepuestoRepository repuestoRepo;

    public StockServiceImpl(RepuestoRepository repuestoRepo) { this.repuestoRepo = repuestoRepo; }

    @Override public long totalRepuestos() { return repuestoRepo.count(); }
    @Override public long repuestosActivos() { return repuestoRepo.findByActivoTrue().size(); }
}
