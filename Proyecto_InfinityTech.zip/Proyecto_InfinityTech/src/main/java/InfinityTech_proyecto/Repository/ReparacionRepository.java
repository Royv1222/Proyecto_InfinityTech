/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Repository;

import InfinityTech_proyecto.Domain.Reparacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReparacionRepository extends JpaRepository<Reparacion, Integer> {
    List<Reparacion> findByTicket_IdTicket(Integer idTicket);
}
