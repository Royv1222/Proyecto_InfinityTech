/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.OrdenServicio;
import InfinityTech_proyecto.Repository.OrdenServicioRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class OrdenServicioServiceImpl implements OrdenServicioService {

    private final OrdenServicioRepository repo;

    public OrdenServicioServiceImpl(OrdenServicioRepository repo) { this.repo = repo; }

    @Override public OrdenServicio save(OrdenServicio o) { return repo.save(o); }
    @Override public OrdenServicio findById(Integer id) { return repo.findById(id).orElse(null); }
    @Override public List<OrdenServicio> findAll() { return repo.findAll(); }
}
