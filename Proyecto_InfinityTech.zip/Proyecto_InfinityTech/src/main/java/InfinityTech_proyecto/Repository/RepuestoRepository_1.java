/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Historias.demo.repository;


import Historias.demo.domain.Repuesto;

import java.util.HashMap;
import java.util.Map;

public class RepuestoRepository {

    private Map<String, Repuesto> db = new HashMap<>();

    public void guardar(Repuesto repuesto) {
        db.put(repuesto.getNombre(), repuesto);
    }

    public Repuesto buscar(String nombre) {
        return db.get(nombre);
    }
}
