/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.config;

import InfinityTech_proyecto.Domain.Role;
import InfinityTech_proyecto.Domain.User;
import InfinityTech_proyecto.Repository.RoleRepository;
import InfinityTech_proyecto.Repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataSeeder {

    @Bean
    CommandLineRunner init(RoleRepository roleRepo, UserRepository userRepo, PasswordEncoder encoder) {
        return args -> {

            Role adminRole = roleRepo.findByNombre("ADMIN").orElseGet(() -> {
                Role r = new Role();
                r.setNombre("ADMIN");
                return roleRepo.save(r);
            });

            Role tecnicoRole = roleRepo.findByNombre("TECNICO").orElseGet(() -> {
                Role r = new Role();
                r.setNombre("TECNICO");
                return roleRepo.save(r);
            });

            if (userRepo.findByUsuario("admin").isEmpty()) {
                User u = new User();
                u.setNombre("Administrador");
                u.setUsuario("admin");
                u.setCorreo("admin@infinitytech.com");
                u.setPassword(encoder.encode("123"));
                u.setRole(adminRole);
                u.setActivo(true);
                userRepo.save(u);
            }

            if (userRepo.findByUsuario("tecnico").isEmpty()) {
                User u = new User();
                u.setNombre("Técnico");
                u.setUsuario("tecnico");
                u.setCorreo("tecnico@infinitytech.com");
                u.setPassword(encoder.encode("123"));
                u.setRole(tecnicoRole);
                u.setActivo(true);
                userRepo.save(u);
            }
        };
    }
}
