/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Historias.demo.service;


import Historias.demo.domain.Repuesto;
import Historias.demo.repository.RepuestoRepository;

public class StockService {

    private RepuestoRepository repository = new RepuestoRepository();

    public String actualizarStock(String nombre, int nuevoStock) {
        Repuesto r = repository.buscar(nombre);

        if (r == null) return "Repuesto no encontrado";

        r.setStock(nuevoStock);
        repository.guardar(r);

        if (r.getMinimo() == null) {
            return "Nivel mínimo no definido";
        }

        if (nuevoStock <= r.getMinimo()) {
            // Aquí se enviaría notificación real
            return "ALERTA: stock mínimo alcanzado para " + nombre;
        }

        return "Stock actualizado correctamente";
    }
}

