/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.OrdenServicio;
import InfinityTech_proyecto.Service.OrdenServicioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/ordenservicio")
public class OrdenServicioController {

    private final OrdenServicioService service;

    public OrdenServicioController(OrdenServicioService service) { this.service = service; }

    @GetMapping
    public String form(Model model) {
        model.addAttribute("orden", new OrdenServicio());
        return "ordenservicio/orden-servicio";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("orden") OrdenServicio orden) {
        service.save(orden);
        return "redirect:/home";
    }
}
