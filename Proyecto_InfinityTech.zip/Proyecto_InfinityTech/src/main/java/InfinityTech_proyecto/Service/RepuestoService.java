/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Repuesto;
import java.util.List;

public interface RepuestoService {
    List<Repuesto> findAll();
    Repuesto findById(Integer id);
    Repuesto save(Repuesto r);
    void delete(Integer id);
}
