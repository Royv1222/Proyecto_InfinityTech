/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hu.JoseCuadra.models;

/**
Grupo 3
Avance 3
Hecho por Jose Daniel Ramírez Leitón y Sebastián Cuadra Corrales.
HU11, HU12, HU13, HU14 y HU15.
 */

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="tickets")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique=true)
    private String folio;

    private String clienteId;
    private String clienteEmail;
    private String estado;
    private LocalDateTime fechaIngreso;
    private LocalDateTime fechaCierre;
    private BigDecimal costoTotal;

    @Column(columnDefinition="TEXT")
    private String descripcion;

    // getters/setters
}
