/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Historias.demo.controller;


import Historias.demo.service.StockService;

public class StockController {

    private StockService service = new StockService();

    public String actualizar(String nombre, int stock) {
        return service.actualizarStock(nombre, stock);
    }
}
