/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.User;
import InfinityTech_proyecto.Repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository repo;

    public UserServiceImpl(UserRepository repo) { this.repo = repo; }

    @Override public List<User> findAll() { return repo.findAll(); }
    @Override public User findById(Integer id) { return repo.findById(id).orElse(null); }
    @Override public User save(User u) { return repo.save(u); }
    @Override public void delete(Integer id) { repo.deleteById(id); }
    @Override public List<User> findTecnicos() { return repo.findByRole_Nombre("TECNICO"); }
}
