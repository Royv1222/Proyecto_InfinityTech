package InfinityTech_proyecto.Repository;

import InfinityTech_proyecto.Domain.Repuesto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.List;

public interface RepuestoRepository extends JpaRepository<Repuesto, Integer> {
    Optional<Repuesto> findByCodigo(String codigo);
    List<Repuesto> findByActivoTrue();
}