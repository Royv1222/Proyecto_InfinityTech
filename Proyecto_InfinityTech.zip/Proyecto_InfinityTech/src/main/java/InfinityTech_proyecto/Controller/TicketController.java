/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.Ticket;
import InfinityTech_proyecto.Service.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/tickets")
public class TicketController {

    private final TicketService ticketService;
    private final ClienteService clienteService;
    private final TecnicoService tecnicoService;

    public TicketController(TicketService ticketService, ClienteService clienteService, TecnicoService tecnicoService) {
        this.ticketService = ticketService;
        this.clienteService = clienteService;
        this.tecnicoService = tecnicoService;
    }

    @GetMapping
    public String lista(Model model) {
        model.addAttribute("tickets", ticketService.findAll());
        return "tickets/lista";
    }

    @GetMapping("/nuevo")
    public String form(Model model) {
        model.addAttribute("ticket", new Ticket());
        model.addAttribute("clientes", clienteService.findAll());
        model.addAttribute("tecnicos", tecnicoService.listarTecnicos());
        return "tickets/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Ticket ticket) {
        ticketService.save(ticket);
        return "redirect:/tickets";
    }

    @GetMapping("/asignar/{id}")
    public String asignarForm(@PathVariable Integer id, Model model) {
        model.addAttribute("ticket", ticketService.findById(id));
        model.addAttribute("tecnicos", tecnicoService.listarTecnicos());
        return "tickets/asignar-tecnico";
    }

    @PostMapping("/asignar")
    public String asignar(@RequestParam Integer idTicket, @RequestParam Integer idTecnico) {
        ticketService.asignarTecnico(idTicket, idTecnico);
        return "redirect:/tickets";
    }

    @GetMapping("/estado/{id}")
    public String cambiarEstadoForm(@PathVariable Integer id, Model model) {
        model.addAttribute("ticket", ticketService.findById(id));
        return "tickets/cambiar-estado";
    }

    @PostMapping("/estado")
    public String cambiarEstado(@RequestParam Integer idTicket, @RequestParam String estado) {
        ticketService.cambiarEstado(idTicket, estado);
        return "redirect:/tickets";
    }
}
