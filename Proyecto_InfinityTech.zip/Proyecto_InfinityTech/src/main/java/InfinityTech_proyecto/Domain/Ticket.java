/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tickets")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ticket")
    private Integer idTicket;

    @Column(nullable = false, unique = true, length = 30)
    private String folio;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_cliente")
    private Cliente cliente;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_equipo")
    private Equipo equipo;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_estado")
    private EstadoTicket estado;

    @Lob
    @Column(name = "descripcion_falla", nullable = false)
    private String descripcionFalla;

    @Lob
    @Column(name = "accesorios_recibidos")
    private String accesoriosRecibidos;

    @Column(name = "firma_entrega", length = 120)
    private String firmaEntrega;

    @ManyToOne
    @JoinColumn(name = "id_tecnico_asignado")
    private User tecnicoAsignado;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;

    @Column(name = "fecha_ultimo_estado", nullable = false)
    private LocalDateTime fechaUltimoEstado;

    @Column(name = "motivo_cancelacion", length = 200)
    private String motivoCancelacion;

    @PrePersist
    void onCreate() {
        if (fechaCreacion == null) fechaCreacion = LocalDateTime.now();
        if (fechaUltimoEstado == null) fechaUltimoEstado = LocalDateTime.now();
    }

    @PreUpdate
    void onUpdate() { fechaUltimoEstado = LocalDateTime.now(); }

    public Integer getIdTicket() { return idTicket; }
    public void setIdTicket(Integer idTicket) { this.idTicket = idTicket; }

    public String getFolio() { return folio; }
    public void setFolio(String folio) { this.folio = folio; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public Equipo getEquipo() { return equipo; }
    public void setEquipo(Equipo equipo) { this.equipo = equipo; }

    public EstadoTicket getEstado() { return estado; }
    public void setEstado(EstadoTicket estado) { this.estado = estado; }

    public String getDescripcionFalla() { return descripcionFalla; }
    public void setDescripcionFalla(String descripcionFalla) { this.descripcionFalla = descripcionFalla; }

    public String getAccesoriosRecibidos() { return accesoriosRecibidos; }
    public void setAccesoriosRecibidos(String accesoriosRecibidos) { this.accesoriosRecibidos = accesoriosRecibidos; }

    public String getFirmaEntrega() { return firmaEntrega; }
    public void setFirmaEntrega(String firmaEntrega) { this.firmaEntrega = firmaEntrega; }

    public User getTecnicoAsignado() { return tecnicoAsignado; }
    public void setTecnicoAsignado(User tecnicoAsignado) { this.tecnicoAsignado = tecnicoAsignado; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public LocalDateTime getFechaUltimoEstado() { return fechaUltimoEstado; }
    public void setFechaUltimoEstado(LocalDateTime fechaUltimoEstado) { this.fechaUltimoEstado = fechaUltimoEstado; }

    public String getMotivoCancelacion() { return motivoCancelacion; }
    public void setMotivoCancelacion(String motivoCancelacion) { this.motivoCancelacion = motivoCancelacion; }
}

