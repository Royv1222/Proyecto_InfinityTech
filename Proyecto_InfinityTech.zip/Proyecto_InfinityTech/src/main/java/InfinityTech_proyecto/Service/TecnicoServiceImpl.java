/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.User;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TecnicoServiceImpl implements TecnicoService {

    private final UserService userService;

    public TecnicoServiceImpl(UserService userService) { this.userService = userService; }

    @Override
    public List<User> listarTecnicos() {
        return userService.findTecnicos();
    }
}