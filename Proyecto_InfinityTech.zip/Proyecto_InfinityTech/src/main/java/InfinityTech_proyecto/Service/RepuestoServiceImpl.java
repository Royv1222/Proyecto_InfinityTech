/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Repuesto;
import InfinityTech_proyecto.Repository.RepuestoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RepuestoServiceImpl implements RepuestoService {

    private final RepuestoRepository repo;

    public RepuestoServiceImpl(RepuestoRepository repo) { this.repo = repo; }

    @Override public List<Repuesto> findAll() { return repo.findAll(); }
    @Override public Repuesto findById(Integer id) { return repo.findById(id).orElse(null); }
    @Override public Repuesto save(Repuesto r) { return repo.save(r); }
    @Override public void delete(Integer id) { repo.deleteById(id); }
}