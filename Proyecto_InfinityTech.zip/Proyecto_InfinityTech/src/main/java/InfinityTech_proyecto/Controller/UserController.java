/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.User;
import InfinityTech_proyecto.Service.RoleService;
import InfinityTech_proyecto.Service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/usuarios")
public class UserController {

    private final UserService userService;
    private final RoleService roleService;

    public UserController(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("usuarios", userService.findAll());
        return "admin/usuarios/list";
    }

    @GetMapping("/nuevo")
    public String form(Model model) {
        model.addAttribute("usuario", new User());
        model.addAttribute("roles", roleService.findAll());
        return "admin/usuarios/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("usuario") User u) {
        userService.save(u);
        return "redirect:/admin/usuarios";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Integer id, Model model) {
        model.addAttribute("usuario", userService.findById(id));
        model.addAttribute("roles", roleService.findAll());
        return "admin/usuarios/form";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Integer id) {
        userService.delete(id);
        return "redirect:/admin/usuarios";
    }
}
