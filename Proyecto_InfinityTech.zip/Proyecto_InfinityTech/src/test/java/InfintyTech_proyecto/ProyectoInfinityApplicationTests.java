package InfintyTech_proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoInfinityApplicationTests {

	@Test
	void contextLoads() {
	}

}
