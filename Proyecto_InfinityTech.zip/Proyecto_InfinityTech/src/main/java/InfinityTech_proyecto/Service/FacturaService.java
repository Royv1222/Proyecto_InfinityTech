/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Factura;
import java.util.List;

public interface FacturaService {
    List<Factura> findAll();
    Factura findById(Integer id);
    Factura save(Factura factura);
    void deleteById(Integer id);

}

