package InfinityTech_proyecto.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/public")
public class PublicController {

    @GetMapping("/seleccionar-servicio")
    public String seleccionarServicio() {
        return "public/seleccionar-servicio";
    }

    @GetMapping("/solicitud")
    public String solicitudForm() {
        return "public/solicitud-form";
    }

    @GetMapping("/estado")
    public String estado() {
        return "public/estado-ticket";
    }
}