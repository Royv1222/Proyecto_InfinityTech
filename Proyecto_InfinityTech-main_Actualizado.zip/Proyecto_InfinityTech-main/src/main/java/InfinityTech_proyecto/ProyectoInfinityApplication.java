package InfinityTech_proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoInfinityApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoInfinityApplication.class, args);
    }
}