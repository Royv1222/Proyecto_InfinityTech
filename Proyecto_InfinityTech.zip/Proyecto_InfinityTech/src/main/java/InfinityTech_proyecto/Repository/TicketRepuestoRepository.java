/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Repository;

import InfinityTech_proyecto.Domain.TicketRepuesto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TicketRepuestoRepository extends JpaRepository<TicketRepuesto, Integer> {
    List<TicketRepuesto> findByTicket_IdTicket(Integer idTicket);
    Optional<TicketRepuesto> findByTicket_IdTicketAndRepuesto_IdRepuestoAndEstado(Integer idTicket, Integer idRepuesto, TicketRepuesto.EstadoMov estado);
}

