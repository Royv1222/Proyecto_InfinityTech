/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hu.JoseCuadra.services;

/**
Grupo 3
Avance 3
Hecho por Jose Daniel Ramírez Leitón y Sebastián Cuadra Corrales.
HU11, HU12, HU13, HU14 y HU15.
 */
import java.util.HashMap;

public class ControlTiemposService {

    private HashMap<String, Reparacion> reparaciones = new HashMap<>();

    public void iniciarReparacion(String idEquipo) {
        Reparacion r = new Reparacion(idEquipo);
        r.iniciar();
        reparaciones.put(idEquipo, r);
    }

    public void finalizarReparacion(String idEquipo) {
        if (reparaciones.containsKey(idEquipo)) {
            reparaciones.get(idEquipo).finalizar();
        }
    }

    public String obtenerEstado(String idEquipo) {
        if (!reparaciones.containsKey(idEquipo)) 
            return "No existe reparación registrada";

        return reparaciones.get(idEquipo).getEstado();
    }

    public Long obtenerTiempo(String idEquipo) {
        if (!reparaciones.containsKey(idEquipo))
            return null;
        return reparaciones.get(idEquipo).getTiempoTotal();
    }
}
