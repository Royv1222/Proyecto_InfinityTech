/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Reparacion;
import InfinityTech_proyecto.Domain.Ticket;
import InfinityTech_proyecto.Domain.User;
import InfinityTech_proyecto.Repository.ReparacionRepository;
import InfinityTech_proyecto.Repository.TicketRepository;
import InfinityTech_proyecto.Repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReparacionServiceImpl implements ReparacionService {

    private final ReparacionRepository repo;
    private final TicketRepository ticketRepo;
    private final UserRepository userRepo;

    public ReparacionServiceImpl(ReparacionRepository repo, TicketRepository ticketRepo, UserRepository userRepo) {
        this.repo = repo;
        this.ticketRepo = ticketRepo;
        this.userRepo = userRepo;
    }

    @Override
    public Reparacion iniciar(Integer idTicket, Integer idTecnico, Reparacion.Tipo tipo) {
        Ticket t = ticketRepo.findById(idTicket).orElse(null);
        User u = userRepo.findById(idTecnico).orElse(null);
        if (t == null || u == null) return null;

        Reparacion r = new Reparacion();
        r.setTicket(t);
        r.setTecnico(u);
        r.setTipo(tipo);
        r.setInicio(LocalDateTime.now());
        return repo.save(r);
    }

    @Override
    public Reparacion finalizar(Integer idTiempo) {
        Reparacion r = repo.findById(idTiempo).orElse(null);
        if (r == null) return null;
        r.setFin(LocalDateTime.now());
        return repo.save(r);
    }

    @Override
    public List<Reparacion> porTicket(Integer idTicket) {
        return repo.findByTicket_IdTicket(idTicket);
    }
}
