/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.EstadoTicket;
import InfinityTech_proyecto.Domain.Ticket;
import InfinityTech_proyecto.Domain.User;
import InfinityTech_proyecto.Repository.EstadoTicketRepository;
import InfinityTech_proyecto.Repository.TicketRepository;
import InfinityTech_proyecto.Repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class TicketServiceImpl implements TicketService {

    private final TicketRepository ticketRepo;
    private final EstadoTicketRepository estadoRepo;
    private final UserRepository userRepo;

    public TicketServiceImpl(TicketRepository ticketRepo,
                             EstadoTicketRepository estadoRepo,
                             UserRepository userRepo) {
        this.ticketRepo = ticketRepo;
        this.estadoRepo = estadoRepo;
        this.userRepo = userRepo;
    }

    // --------------------
    // CRUD
    // --------------------
    @Override
    public Ticket save(Ticket t) {
        return ticketRepo.save(t);
    }

    @Override
    @Transactional(readOnly = true)
    public Ticket findById(Integer id) {
        return ticketRepo.findById(id).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Ticket> findAll() {
        return ticketRepo.findAll();
    }

    @Override
    public void delete(Integer id) {
        ticketRepo.deleteById(id);
    }

    // --------------------
    // Lógica de negocio
    // --------------------
    @Override
    public Ticket asignarTecnico(Integer idTicket, Integer idTecnico) {
        if (idTicket == null || idTecnico == null) return null;

        Ticket t = ticketRepo.findById(idTicket).orElse(null);
        if (t == null) return null;

        User tecnico = userRepo.findById(idTecnico).orElse(null);
        if (tecnico == null) {
            throw new IllegalArgumentException("Técnico no encontrado: " + idTecnico);
        }

        // Si tu entidad Ticket tiene el campo tecnico asignado como User:
        try {
            t.setTecnicoAsignado(tecnico);
        } catch (Exception e) {
            // Si en tu Ticket el campo es otro (por ejemplo setIdTecnicoAsignado),
            // cambiá esta línea por el setter correcto.
            throw new IllegalStateException("Revisa el setter del técnico en Ticket (no coincide con setTecnicoAsignado(User)).");
        }

        // si tu Ticket tiene fechaUltimoEstado:
        try {
            t.setFechaUltimoEstado(LocalDateTime.now());
        } catch (Exception ignored) {}

        return ticketRepo.save(t);
    }

    @Override
    public Ticket cambiarEstado(Integer idTicket, String nombreEstado) {
        if (idTicket == null) return null;
        if (nombreEstado == null || nombreEstado.trim().isEmpty()) return null;

        Ticket t = ticketRepo.findById(idTicket).orElse(null);
        if (t == null) return null;

        String estadoNorm = nombreEstado.trim().toUpperCase();

        EstadoTicket est = estadoRepo.findByNombre(estadoNorm).orElse(null);
        if (est == null) {
            throw new IllegalArgumentException("Estado no existe: " + estadoNorm);
        }

        // ✅ Ajustá si tu setter se llama distinto (setEstadoTicket, etc.)
        t.setEstado(est);

        try {
            t.setFechaUltimoEstado(LocalDateTime.now());
        } catch (Exception ignored) {}

        return ticketRepo.save(t);
    }

    @Override
    @Transactional(readOnly = true)
    public Ticket buscarPorFolio(String folio) {
        if (folio == null) return null;
        String f = folio.trim();
        if (f.isEmpty()) return null;

        return ticketRepo.findByFolio(f).orElse(null);
    }
}
