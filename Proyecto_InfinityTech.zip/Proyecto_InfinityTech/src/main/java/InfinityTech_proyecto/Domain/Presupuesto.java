/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Domain;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "presupuestos")
public class Presupuesto {

    public enum Estado { GENERADO, ENVIADO, APROBADO, RECHAZADO }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_presupuesto")
    private Integer idPresupuesto;

    @OneToOne(optional = false)
    @JoinColumn(name = "id_ticket", unique = true)
    private Ticket ticket;

    @Column(name = "mano_obra_horas", nullable = false)
    private Double manoObraHoras = 0.0;

    @Column(name = "tarifa_hora", nullable = false)
    private Double tarifaHora = 0.0;

    @Column(name = "subtotal_repuestos", nullable = false)
    private Double subtotalRepuestos = 0.0;

    @Column(name = "subtotal_mano_obra", nullable = false)
    private Double subtotalManoObra = 0.0;

    @Column(nullable = false)
    private Double impuestos = 0.0;

    @Column(nullable = false)
    private Double total = 0.0;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Estado estado = Estado.GENERADO;

    @Column(name = "fecha_generacion", nullable = false)
    private LocalDateTime fechaGeneracion;

    @Column(name = "fecha_respuesta")
    private LocalDateTime fechaRespuesta;

    @Column(length = 200)
    private String notas;

    @PrePersist
    void onCreate() { if (fechaGeneracion == null) fechaGeneracion = LocalDateTime.now(); }

    public Integer getIdPresupuesto() { return idPresupuesto; }
    public void setIdPresupuesto(Integer idPresupuesto) { this.idPresupuesto = idPresupuesto; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) { this.ticket = ticket; }

    public Double getManoObraHoras() { return manoObraHoras; }
    public void setManoObraHoras(Double manoObraHoras) { this.manoObraHoras = manoObraHoras; }

    public Double getTarifaHora() { return tarifaHora; }
    public void setTarifaHora(Double tarifaHora) { this.tarifaHora = tarifaHora; }

    public Double getSubtotalRepuestos() { return subtotalRepuestos; }
    public void setSubtotalRepuestos(Double subtotalRepuestos) { this.subtotalRepuestos = subtotalRepuestos; }

    public Double getSubtotalManoObra() { return subtotalManoObra; }
    public void setSubtotalManoObra(Double subtotalManoObra) { this.subtotalManoObra = subtotalManoObra; }

    public Double getImpuestos() { return impuestos; }
    public void setImpuestos(Double impuestos) { this.impuestos = impuestos; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public Estado getEstado() { return estado; }
    public void setEstado(Estado estado) { this.estado = estado; }

    public LocalDateTime getFechaGeneracion() { return fechaGeneracion; }
    public void setFechaGeneracion(LocalDateTime fechaGeneracion) { this.fechaGeneracion = fechaGeneracion; }

    public LocalDateTime getFechaRespuesta() { return fechaRespuesta; }
    public void setFechaRespuesta(LocalDateTime fechaRespuesta) { this.fechaRespuesta = fechaRespuesta; }

    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }
}

