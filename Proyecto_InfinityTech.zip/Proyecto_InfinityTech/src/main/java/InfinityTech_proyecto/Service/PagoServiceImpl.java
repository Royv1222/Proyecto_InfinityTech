/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.Pago;
import InfinityTech_proyecto.Repository.PagoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PagoServiceImpl implements PagoService {

    private final PagoRepository repo;

    public PagoServiceImpl(PagoRepository repo) { this.repo = repo; }

    @Override public Pago save(Pago p) { return repo.save(p); }
    @Override public List<Pago> pagosPorFactura(Integer idFactura) { return repo.findByFactura_IdFactura(idFactura); }
}
