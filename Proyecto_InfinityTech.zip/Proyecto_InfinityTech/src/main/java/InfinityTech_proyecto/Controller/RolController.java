/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Domain.Role;
import InfinityTech_proyecto.Service.RoleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/roles")
public class RolController {

    private final RoleService roleService;

    public RolController(RoleService roleService) {
        this.roleService = roleService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("roles", roleService.findAll());
        return "admin/roles/list";
    }

    @GetMapping("/nuevo")
    public String form(Model model) {
        model.addAttribute("rol", new Role());
        return "admin/roles/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("rol") Role r) {
        roleService.save(r);
        return "redirect:/admin/roles";
    }
}

