/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package InfinityTech_proyecto.Controller;

import InfinityTech_proyecto.Service.InventarioService;
import InfinityTech_proyecto.Service.RepuestoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/repuestos")
public class InventarioController {

    private final RepuestoService repuestoService;
    private final InventarioService inventarioService;

    public InventarioController(RepuestoService repuestoService, InventarioService inventarioService) {
        this.repuestoService = repuestoService;
        this.inventarioService = inventarioService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("repuestos", repuestoService.findAll());
        return "repuestos/reservar"; // o "repuestos/list" si lo creaste
    }

    @PostMapping("/reservar")
    public String reservar(@RequestParam Integer idTicket, @RequestParam Integer idRepuesto, @RequestParam Integer cantidad) {
        inventarioService.reservar(idTicket, idRepuesto, cantidad);
        return "redirect:/tickets";
    }
}
