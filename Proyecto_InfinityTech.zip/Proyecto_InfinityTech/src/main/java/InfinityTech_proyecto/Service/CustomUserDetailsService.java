/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.User;
import InfinityTech_proyecto.Repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepo;

    public CustomUserDetailsService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String usernameOrEmail) throws UsernameNotFoundException {

        User u = userRepo.findByUsuario(usernameOrEmail)
                .or(() -> userRepo.findByCorreo(usernameOrEmail))
                .orElseThrow(() -> new UsernameNotFoundException("Usuario o correo no encontrado: " + usernameOrEmail));

        // 
        boolean activo = (u.getActivo() != null) && u.getActivo();
        if (!activo) {
            throw new UsernameNotFoundException("Usuario inactivo: " + usernameOrEmail);
        }

        String rol = (u.getRole() != null && u.getRole().getNombre() != null)
                ? u.getRole().getNombre().toUpperCase()
                : "TECNICO";

        return org.springframework.security.core.userdetails.User
                .withUsername(u.getUsuario()) // o u.getCorreo() si preferís
                .password(u.getPassword())
                .authorities(List.of(new SimpleGrantedAuthority("ROLE_" + rol)))
                .build();
    }
}

