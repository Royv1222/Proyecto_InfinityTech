package InfinityTech_proyecto.Service;

import InfinityTech_proyecto.Domain.TicketRepuesto;
import java.util.List;

public interface InventarioService {
    TicketRepuesto reservar(Integer idTicket, Integer idRepuesto, Integer cantidad);
    TicketRepuesto consumir(Integer idTicket, Integer idRepuesto, Integer cantidad);
    TicketRepuesto devolver(Integer idTicket, Integer idRepuesto, Integer cantidad);
    List<TicketRepuesto> movimientosPorTicket(Integer idTicket);
}
